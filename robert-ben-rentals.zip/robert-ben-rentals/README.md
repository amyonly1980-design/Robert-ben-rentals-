# Robert Ben Rental Property

Zillow-style rental MVP built with React + Vite.

Features:
- Rental listings and property detail pages
- Search and price/beds/baths filters
- Leaflet + OpenStreetMap map
- Browser-only admin JSON editor
- Responsive design

Run locally:
1. Install Node.js.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

Important:
- The sample listings are placeholders.
- Replace photos, addresses, prices, descriptions, and contact details before publishing.
- The Admin page is not secure authentication; it is only a development editor.
